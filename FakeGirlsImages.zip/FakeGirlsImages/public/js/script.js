
const gallery = document.getElementById("galleryContainer");

const totalImages = 25;
let currentImage = 0;

const lightbox = document.getElementById("lightbox");
const previewImage = document.getElementById("previewImage");
const imageCounter = document.getElementById("imageCounter");

const imagePaths = [];

for (let i = 1; i <= totalImages; i++) {
    imagePaths.push(`images/girl${i}.jpg`);
}

imagePaths.forEach((path, index) => {

    const card = document.createElement("div");
    card.className = "photo-card";

    card.innerHTML = `
        <img src="${path}" alt="Fictional AI portrait ${index + 1}" loading="lazy">
        <div class="photo-info">
            <h3>Portrait ${String(index + 1).padStart(2, "0")}</h3>
            <p>Fictional AI Generated Image</p>
        </div>
    `;

    card.addEventListener("click", () => {
        currentImage = index;
        showImage();
        lightbox.classList.add("active");
    });

    gallery.appendChild(card);
});

function showImage() {
    previewImage.src = imagePaths[currentImage];
    imageCounter.textContent =
        `${currentImage + 1} / ${totalImages}`;
}

document.getElementById("closeBtn").onclick = () => {
    lightbox.classList.remove("active");
};

document.getElementById("nextBtn").onclick = () => {
    currentImage = (currentImage + 1) % totalImages;
    showImage();
};

document.getElementById("prevBtn").onclick = () => {
    currentImage = (currentImage - 1 + totalImages) % totalImages;
    showImage();
};

lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) {
        lightbox.classList.remove("active");
    }
});

document.addEventListener("keydown", (e) => {

    if (!lightbox.classList.contains("active")) return;

    if (e.key === "Escape") {
        lightbox.classList.remove("active");
    }

    if (e.key === "ArrowRight") {
        currentImage = (currentImage + 1) % totalImages;
        showImage();
    }

    if (e.key === "ArrowLeft") {
        currentImage = (currentImage - 1 + totalImages) % totalImages;
        showImage();
    }
});
